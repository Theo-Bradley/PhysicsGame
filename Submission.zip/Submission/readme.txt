Controls:
-Left click to interact with the UI
-Left click to place a bomb at the mouse position
-Right click to move the launch log to the mouse position

Known Issues:
-As mentioned in the video, if the player can fire two bombs within 100ms they can fire more than assigned

Files:
Game/BadTemperedBirds.exe - Game Executable
Bad tempered Birds.docx - Game Design Document
BadTemperedBirds.mp4 - Video Demo
https://github.com/Theo-Bradley/PhysicsGame - Source